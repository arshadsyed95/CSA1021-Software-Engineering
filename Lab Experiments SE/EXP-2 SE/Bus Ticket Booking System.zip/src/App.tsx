import { useState, type ReactNode } from "react";

type Screen =
  | "home"
  | "results"
  | "seats"
  | "passenger"
  | "payment"
  | "confirmation"
  | "bookings"
  | "login"
  | "signup";

type IconName =
  | "bus"
  | "arrow"
  | "calendar"
  | "users"
  | "swap"
  | "search"
  | "clock"
  | "star"
  | "map"
  | "chevron"
  | "user"
  | "card"
  | "shield"
  | "check"
  | "download"
  | "ticket"
  | "home"
  | "google"
  | "menu"
  | "seat";

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
  };
  const paths: Record<IconName, ReactNode> = {
    bus: <><path d="M6 17h12M6 4h12a2 2 0 0 1 2 2v11H4V6a2 2 0 0 1 2-2Z" /><path d="M4 11h16M8 7h8M7 17v2M17 17v2" /><circle cx="7.5" cy="14" r=".6" fill="currentColor" /><circle cx="16.5" cy="14" r=".6" fill="currentColor" /></>,
    arrow: <><path d="M5 12h14M14 7l5 5-5 5" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></>,
    swap: <><path d="m7 7-4 4 4 4M3 11h14M17 17l4-4-4-4M21 13H7" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    star: <path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z" />,
    map: <><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3V6Z" /><path d="M9 3v15M15 6v15" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    card: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18M7 15h4" /></>,
    shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-4" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    download: <><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 20h14" /></>,
    ticket: <><path d="M3 8a2 2 0 0 0 0 4v5h18v-5a2 2 0 0 0 0-4V3H3v5Z" /><path d="M13 6h4M13 10h4M13 14h4M9 3v14" /></>,
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
    google: <><path d="M21 12.2c0-.7-.1-1.3-.2-1.9H12v3.6h5a4.3 4.3 0 0 1-1.9 2.8V19h3c1.8-1.6 2.9-4 2.9-6.8Z" /><path d="M12 21c2.5 0 4.6-.8 6.1-2.2l-3-2.3c-.8.6-1.9.9-3.1.9-2.4 0-4.5-1.7-5.2-3.9h-3v2.4A9.2 9.2 0 0 0 12 21Z" /><path d="M6.8 13.5a5.5 5.5 0 0 1 0-3V8.1h-3a9.1 9.1 0 0 0 0 7.8l3-2.4Z" /><path d="M12 6.6c1.4 0 2.6.5 3.5 1.4l2.7-2.7A9 9 0 0 0 3.8 8.1l3 2.4A5.5 5.5 0 0 1 12 6.6Z" /></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    seat: <><path d="M7 12V7a3 3 0 0 1 6 0v5M5 12h10a2 2 0 0 1 2 2v5H5v-7Z" /><path d="M5 16H3v-3M17 16h2v-3M8 19v2M14 19v2" /></>,
  };
  return <svg {...common}>{paths[name]}</svg>;
}

function Clickable({ children, onClick, className = "", label }: { children: ReactNode; onClick?: () => void; className?: string; label?: string }) {
  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={label}
      className={`cursor-pointer select-none ${className}`}
      onClick={onClick}
      onKeyDown={(e) => {
        if ((e.key === "Enter" || e.key === " ") && onClick) onClick();
      }}
    >
      {children}
    </div>
  );
}

function Button({ children, onClick, variant = "primary", icon, full = false }: { children: ReactNode; onClick?: () => void; variant?: "primary" | "secondary" | "ghost" | "danger"; icon?: IconName; full?: boolean }) {
  return <Clickable onClick={onClick} className={`btn btn-${variant} ${full ? "w-full" : ""}`}>{icon && <Icon name={icon} size={18} />}<span>{children}</span></Clickable>;
}

function Logo({ onClick }: { onClick: () => void }) {
  return <Clickable onClick={onClick} className="logo"><span className="logo-mark"><Icon name="bus" size={22} /></span><span>BusGo</span></Clickable>;
}

function Header({ screen, go }: { screen: Screen; go: (screen: Screen) => void }) {
  const [open, setOpen] = useState(false);
  const nav = [
    ["Home", "home"],
    ["Search Buses", "results"],
    ["My Bookings", "bookings"],
    ["Help", "home"],
  ] as [string, Screen][];
  return (
    <div className="header">
      <div className="header-inner">
        <Logo onClick={() => go("home")} />
        <div className={`nav ${open ? "nav-open" : ""}`}>
          {nav.map(([label, target]) => <Clickable key={label} onClick={() => { go(target); setOpen(false); }} className={`nav-item ${screen === target ? "active" : ""}`}>{label}</Clickable>)}
          <div className="mobile-login"><Button onClick={() => go("login")} variant="secondary">Login</Button></div>
        </div>
        <div className="desktop-login"><Button onClick={() => go("login")} variant="secondary">Login</Button></div>
        <Clickable onClick={() => setOpen(!open)} className="menu-button" label="Toggle menu"><Icon name="menu" /></Clickable>
      </div>
    </div>
  );
}

const steps = ["Select Bus", "Select Seat", "Passenger", "Payment", "Confirmation"];

function Progress({ current }: { current: number }) {
  return (
    <div className="progress">
      {steps.map((step, index) => (
        <div className={`progress-step ${index <= current ? "done" : ""} ${index === current ? "current" : ""}`} key={step}>
          <div className="progress-dot">{index < current ? <Icon name="check" size={14} /> : index + 1}</div>
          <div className="progress-label">{step}</div>
          {index < steps.length - 1 && <div className="progress-line" />}
        </div>
      ))}
    </div>
  );
}

function Field({ label, value, icon, type }: { label: string; value: string; icon?: IconName; type?: string }) {
  return <div className="field"><div className="field-label">{label}</div><div className="field-control">{icon && <Icon name={icon} size={18} />}<span className={type === "password" ? "password-value" : ""}>{type === "password" ? "••••••••" : value}</span></div></div>;
}

const routes = [
  ["Chennai", "Bengaluru", "₹799"],
  ["Chennai", "Coimbatore", "₹549"],
  ["Bengaluru", "Hyderabad", "₹899"],
  ["Chennai", "Madurai", "₹649"],
];

function Home({ go }: { go: (screen: Screen) => void }) {
  return (
    <>
      <Header screen="home" go={go} />
      <div className="hero">
        <div className="hero-orb orb-one" /><div className="hero-orb orb-two" />
        <div className="container hero-content">
          <div className="eyebrow"><span className="eyebrow-dot" />India's trusted bus booking platform</div>
          <div className="display">Book Your Bus Ticket <span>Easily</span></div>
          <div className="hero-copy">Search, select your seat, and book your bus in just a few clicks.</div>
          <div className="search-panel">
            <div className="search-field"><div className="search-icon"><Icon name="map" /></div><div><div className="search-label">From</div><div className="search-value">Chennai</div></div></div>
            <Clickable className="swap"><Icon name="swap" size={18} /></Clickable>
            <div className="search-field"><div className="search-icon"><Icon name="map" /></div><div><div className="search-label">To</div><div className="search-value">Bengaluru</div></div></div>
            <div className="search-field"><div className="search-icon"><Icon name="calendar" /></div><div><div className="search-label">Date</div><div className="search-value">15 Oct 2026</div></div></div>
            <div className="search-field"><div className="search-icon"><Icon name="users" /></div><div><div className="search-label">Passengers</div><div className="search-value">1 Passenger</div></div></div>
            <Button onClick={() => go("results")} icon="search">Search Buses</Button>
          </div>
          <div className="trust-row"><div><Icon name="shield" size={17} />Secure payments</div><div><Icon name="check" size={17} />Instant confirmation</div><div><Icon name="ticket" size={17} />Easy cancellation</div></div>
        </div>
      </div>
      <div className="section container">
        <div className="section-head"><div><div className="section-title">Popular Routes</div><div className="section-subtitle">Routes loved by thousands of travellers</div></div><Clickable onClick={() => go("results")} className="text-link">View all routes <Icon name="arrow" size={16} /></Clickable></div>
        <div className="route-grid">
          {routes.map(([from, to, price], i) => <Clickable key={to} onClick={() => go("results")} className="route-card"><div className={`route-visual route-${i + 1}`}><span><Icon name="bus" size={26} /></span></div><div className="route-info"><div className="route-cities"><span>{from}</span><Icon name="arrow" size={17} /><span>{to}</span></div><div className="route-bottom"><span>Daily buses</span><strong>From {price}</strong></div></div></Clickable>)}
        </div>
      </div>
      <div className="why-section"><div className="container why-grid"><div className="why-title">Why travel with BusGo?</div>{[["shield", "Safe & secure", "Protected payments and verified operators"], ["seat", "Choose your seat", "See the exact seat before you book"], ["ticket", "Instant tickets", "Get your e-ticket right after payment"]].map(([icon, title, text]) => <div className="why-item" key={title}><div className="why-icon"><Icon name={icon as IconName} /></div><div><strong>{title}</strong><span>{text}</span></div></div>)}</div></div>
      <Footer go={go} />
    </>
  );
}

function Footer({ go }: { go: (screen: Screen) => void }) {
  return <div className="footer"><div className="container footer-inner"><Logo onClick={() => go("home")} /><div className="footer-links">{["About", "Contact", "Help", "Terms", "Privacy"].map(x => <span key={x}>{x}</span>)}</div><div className="copyright">© 2026 BusGo. All rights reserved.</div></div></div>;
}

const buses = [
  { name: "GreenLine Travels", type: "AC Sleeper", depart: "09:00 PM", arrive: "05:30 AM", duration: "8h 30m", price: "₹950", rating: "4.5", seats: 12, featured: true },
  { name: "Orange Tours", type: "Volvo AC Seater", depart: "10:15 PM", arrive: "06:15 AM", duration: "8h 00m", price: "₹1,150", rating: "4.7", seats: 8 },
  { name: "KPN Travels", type: "Non-AC Sleeper", depart: "08:30 PM", arrive: "05:45 AM", duration: "9h 15m", price: "₹750", rating: "4.2", seats: 19 },
  { name: "SRS Travels", type: "AC Sleeper", depart: "11:00 PM", arrive: "07:00 AM", duration: "8h 00m", price: "₹1,050", rating: "4.4", seats: 6 },
];

function Results({ go }: { go: (screen: Screen) => void }) {
  return (
    <>
      <Header screen="results" go={go} />
      <div className="page">
        <div className="container">
          <Progress current={0} />
          <div className="page-heading-row"><div><div className="page-title">Available Buses</div><div className="route-meta"><span>Chennai</span><Icon name="arrow" size={16} /><span>Bengaluru</span><i />15 October 2026</div></div><div className="result-count">24 buses found</div></div>
          <div className="results-layout">
            <div className="filter-card">
              <div className="filter-title"><span>Filters</span><span>Clear all</span></div>
              <FilterGroup title="Bus Type" items={["AC", "Non-AC", "Sleeper", "Seater"]} selected="AC" />
              <FilterGroup title="Departure Time" items={["Before 6 AM", "6 AM – 12 PM", "12 PM – 6 PM", "After 6 PM"]} />
              <FilterGroup title="Price" items={["Under ₹800", "₹800 – ₹1,000", "Above ₹1,000"]} />
              <FilterGroup title="Rating" items={["4.5 & above", "4.0 & above"]} />
            </div>
            <div className="bus-results">
              <div className="sort-row"><span>Sort by</span>{["Recommended", "Price Low–High", "Departure Time", "Rating"].map((x, i) => <Clickable key={x} className={`sort-pill ${i === 0 ? "selected" : ""}`}>{x}</Clickable>)}</div>
              {buses.map((bus) => <BusCard bus={bus} key={bus.name} onSelect={() => go("seats")} />)}
            </div>
          </div>
        </div>
      </div>
      <Footer go={go} />
    </>
  );
}

function FilterGroup({ title, items, selected }: { title: string; items: string[]; selected?: string }) {
  return <div className="filter-group"><div className="filter-group-title">{title}</div>{items.map(item => <Clickable className="check-row" key={item}><span className={`checkbox ${selected === item ? "checked" : ""}`}>{selected === item && <Icon name="check" size={12} />}</span><span>{item}</span></Clickable>)}</div>;
}

function BusCard({ bus, onSelect }: { bus: typeof buses[number]; onSelect: () => void }) {
  return <div className={`bus-card ${bus.featured ? "featured" : ""}`}>{bus.featured && <div className="best-tag">BEST VALUE</div>}<div className="bus-top"><div className="operator"><div className="operator-icon"><Icon name="bus" /></div><div><div className="operator-name">{bus.name}</div><div className="bus-type">{bus.type} <span>•</span> 2+1</div></div></div><div className="rating"><Icon name="star" size={13} />{bus.rating}</div></div><div className="journey-row"><div><strong>{bus.depart}</strong><span>Chennai</span></div><div className="duration"><span>{bus.duration}</span><div><i /><em /><i /></div><small>Overnight</small></div><div className="arrival"><strong>{bus.arrive}</strong><span>Bengaluru</span></div><div className="bus-price"><span>Starts from</span><strong>{bus.price}</strong><small>per seat</small></div></div><div className="bus-bottom"><div className="amenities"><span>Live tracking</span><span>Charging point</span><span>Blanket</span></div><div className="select-area"><span>{bus.seats} seats available</span><Button onClick={onSelect}>Select Seats</Button></div></div></div>;
}

function TripHeader() {
  return <div className="trip-banner"><div className="operator"><div className="operator-icon"><Icon name="bus" /></div><div><div className="operator-name">GreenLine Travels</div><div className="bus-type">AC Sleeper <span>•</span> <b className="inline-rating"><Icon name="star" size={12} />4.5</b></div></div></div><div className="trip-route"><div><strong>09:00 PM</strong><span>Koyambedu Bus Stand</span></div><Icon name="arrow" /><div><strong>05:30 AM</strong><span>Bengaluru Bus Station</span></div></div><div className="trip-date"><Icon name="calendar" size={18} /><div><span>Journey date</span><strong>15 Oct 2026</strong></div></div></div>;
}

function BookingSummary({ action, onAction, compact = false }: { action?: string; onAction?: () => void; compact?: boolean }) {
  return <div className={`summary-card ${compact ? "compact" : ""}`}><div className="summary-title">Booking Summary</div><div className="summary-trip"><div className="summary-route"><span>MAA</span><Icon name="arrow" size={16} /><span>BLR</span></div><div>15 Oct 2026 · 09:00 PM</div></div><div className="summary-line"><span>Seat</span><strong>A2</strong></div><div className="summary-line"><span>Base fare</span><span>₹950</span></div><div className="summary-line"><span>Taxes & fees</span><span>₹50</span></div><div className="summary-total"><span>Total</span><strong>₹1,000</strong></div>{action && <Button onClick={onAction} full>{action}</Button>}<div className="secure-note"><Icon name="shield" size={15} />Secure & encrypted checkout</div></div>;
}

function Seats({ go }: { go: (screen: Screen) => void }) {
  const [selected, setSelected] = useState("A2");
  const occupied = ["A1", "B3", "C2", "D4", "E1"];
  const ladies = ["B4", "E3"];
  const seatNames = ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4", "E1", "E2", "E3", "E4"];
  return <><Header screen="results" go={go} /><div className="page"><div className="container"><Progress current={1} /><div className="page-title with-back"><Clickable onClick={() => go("results")} className="back-icon"><Icon name="arrow" /></Clickable>Select Your Seat</div><TripHeader /><div className="booking-layout"><div className="seat-card"><div className="seat-card-head"><div><div className="card-title">Choose your seat</div><div className="muted">Click on an available seat to select it</div></div><div className="deck-pill">Lower deck</div></div><div className="bus-shell"><div className="driver"><span /><div>DRIVER</div></div><div className="seat-grid">{seatNames.map((seat, index) => { const status = occupied.includes(seat) ? "occupied" : ladies.includes(seat) ? "ladies" : selected === seat ? "selected" : "available"; return <Clickable key={seat} label={`Seat ${seat}, ${status}`} onClick={() => status !== "occupied" && setSelected(seat)} className={`seat seat-${status} ${index % 4 === 2 ? "aisle" : ""}`}><Icon name="seat" size={19} /><span>{seat}</span></Clickable>; })}</div></div><div className="seat-legend">{[["available", "Available"], ["selected", "Selected"], ["occupied", "Occupied"], ["ladies", "Ladies"]].map(([state, label]) => <div key={state}><i className={`legend-seat ${state}`} /><span>{label}</span></div>)}</div></div><BookingSummary action="Continue" onAction={() => go("passenger")} /></div></div></div><Footer go={go} /></>;
}

function Passenger({ go }: { go: (screen: Screen) => void }) {
  return <><Header screen="results" go={go} /><div className="page"><div className="container"><Progress current={2} /><div className="page-title">Passenger Details</div><div className="booking-layout"><div><div className="form-card"><div className="form-card-title"><span>1</span><div><strong>Passenger 1</strong><small>Seat A2 · Adult</small></div></div><div className="form-grid"><div className="span-two"><Field label="Full Name" value="Arshad Khan" icon="user" /></div><Field label="Age" value="21" /><Field label="Gender" value="Male" /><div className="span-two"><Field label="Mobile Number" value="9876543210" /></div><div className="span-two"><Field label="Email Address" value="arshad.khan@email.com" /></div></div><div className="form-note">Your ticket and booking updates will be sent to this email and mobile number.</div></div><div className="button-row"><Button variant="secondary" onClick={() => go("seats")}>Back</Button><Button onClick={() => go("payment")}>Proceed to Payment <Icon name="arrow" size={17} /></Button></div></div><BookingSummary /></div></div></div><Footer go={go} /></>;
}

function Payment({ go }: { go: (screen: Screen) => void }) {
  const [method, setMethod] = useState("UPI");
  return <><Header screen="results" go={go} /><div className="page"><div className="container"><Progress current={3} /><div className="page-title">Complete Your Booking</div><div className="booking-layout"><div><TripHeader /><div className="form-card payment-card"><div className="card-title">Choose payment method</div><div className="payment-tabs">{[["UPI", "UPI"], ["Credit/Debit Card", "card"], ["Net Banking", "shield"]].map(([label, icon]) => <Clickable onClick={() => setMethod(label)} className={`payment-tab ${method === label ? "active" : ""}`} key={label}><Icon name={icon as IconName} /><span>{label}</span>{method === label && <i><Icon name="check" size={11} /></i>}</Clickable>)}</div>{method === "UPI" ? <div className="payment-content"><Field label="UPI ID" value="arshadkhan@upi" /><div className="upi-hint">Enter your UPI ID linked with any UPI app</div></div> : <div className="payment-content"><Field label={method === "Net Banking" ? "Select your bank" : "Card number"} value={method === "Net Banking" ? "Choose a bank" : "1234  ••••  ••••  5678"} /></div>}<Clickable className="terms-check"><span className="checkbox checked"><Icon name="check" size={12} /></span><span>I agree to the BusGo <b>Terms & Conditions</b> and <b>Cancellation Policy</b></span></Clickable></div><div className="button-row"><Button variant="secondary" onClick={() => go("passenger")}>Back</Button></div></div><div><BookingSummary /><div className="pay-action"><Button full icon="shield" onClick={() => go("confirmation")}>Pay ₹1,000</Button><span>You won't be charged twice</span></div></div></div></div></div><Footer go={go} /></>;
}

function QrCode() {
  const cells = [0,1,2,4,6,7,8,9,11,13,15,17,18,19,20,22,24,25,26,28,30,32,33,34,35,36,38,40,42,44,45,46,48,50,52,54,56,58,60,62,63,64,66,68,70,71,72,73,74,76,78,80];
  return <div className="qr">{Array.from({ length: 81 }).map((_, i) => <i key={i} className={cells.includes(i) ? "on" : ""} />)}</div>;
}

function Confirmation({ go }: { go: (screen: Screen) => void }) {
  return <><Header screen="results" go={go} /><div className="page confirmation-page"><div className="container narrow"><Progress current={4} /><div className="success-icon"><Icon name="check" size={31} /></div><div className="confirmation-title">Booking Confirmed!</div><div className="confirmation-copy">Your journey is booked. We've sent the ticket to your email.</div><div className="booking-id">Booking ID <strong>BG20261015001</strong></div><div className="ticket-card"><div className="ticket-accent" /><div className="ticket-head"><Logo onClick={() => go("home")} /><div><span>E-TICKET</span><strong>Confirmed</strong></div></div><div className="ticket-route"><div><strong>Chennai</strong><span>Koyambedu Bus Stand</span></div><div className="ticket-route-line"><Icon name="bus" /><i /></div><div><strong>Bengaluru</strong><span>Bengaluru Bus Station</span></div></div><div className="ticket-details"><TicketDetail label="Passenger" value="Arshad Khan" /><TicketDetail label="Bus" value="GreenLine Travels" /><TicketDetail label="Date" value="15 October 2026" /><TicketDetail label="Time" value="09:00 PM – 05:30 AM" /><TicketDetail label="Seat" value="A2" /><TicketDetail label="Total Paid" value="₹1,000" /></div><div className="ticket-footer"><div><QrCode /><span>Scan at boarding</span></div><div><span>Booking ID</span><strong>BG20261015001</strong><small>Please arrive 15 minutes before departure</small></div></div></div><div className="confirmation-actions"><Button icon="download">Download Ticket</Button><Button variant="secondary" icon="ticket" onClick={() => go("bookings")}>View My Bookings</Button><Button variant="ghost" icon="home" onClick={() => go("home")}>Go to Home</Button></div></div></div><Footer go={go} /></>;
}

function TicketDetail({ label, value }: { label: string; value: string }) {
  return <div><span>{label}</span><strong>{value}</strong></div>;
}

function Bookings({ go }: { go: (screen: Screen) => void }) {
  const [tab, setTab] = useState("Upcoming");
  return <><Header screen="bookings" go={go} /><div className="page"><div className="container bookings-container"><div className="page-title">My Bookings</div><div className="tabs">{["Upcoming", "Completed", "Cancelled"].map((x, i) => <Clickable onClick={() => setTab(x)} className={tab === x ? "active" : ""} key={x}>{x}{i < 2 && <span>{i === 0 ? 1 : 1}</span>}</Clickable>)}</div>{tab === "Upcoming" && <BookingCard upcoming go={go} />}{tab === "Completed" && <BookingCard go={go} />}{tab === "Cancelled" && <div className="empty-state"><div className="empty-icon"><Icon name="ticket" size={28} /></div><strong>No cancelled bookings</strong><span>Your cancelled trips will appear here.</span></div>}<div className="past-label">Recent trip</div>{tab === "Upcoming" && <BookingCard go={go} />}</div></div><Footer go={go} /></>;
}

function BookingCard({ upcoming = false, go }: { upcoming?: boolean; go: (s: Screen) => void }) {
  return <div className="booking-card"><div className="booking-status-row"><div className="operator"><div className="operator-icon"><Icon name="bus" /></div><div><div className="operator-name">{upcoming ? "GreenLine Travels" : "Parveen Travels"}</div><div className="bus-type">{upcoming ? "AC Sleeper" : "Volvo AC Seater"}</div></div></div><span className={`status ${upcoming ? "confirmed" : "completed"}`}>{upcoming ? "Confirmed" : "Completed"}</span></div><div className="booking-route"><div><strong>{upcoming ? "Chennai" : "Bengaluru"}</strong><span>{upcoming ? "09:00 PM" : "07:30 AM"}</span></div><div className="booking-line"><i /><Icon name="bus" size={18} /><i /></div><div><strong>{upcoming ? "Bengaluru" : "Mysuru"}</strong><span>{upcoming ? "05:30 AM" : "10:45 AM"}</span></div></div><div className="booking-meta"><div><span>Journey date</span><strong>{upcoming ? "15 October 2026" : "20 August 2026"}</strong></div><div><span>Seat</span><strong>{upcoming ? "A2" : "12"}</strong></div><div><span>Booking ID</span><strong>{upcoming ? "BG20261015001" : "BG20260820084"}</strong></div><div><span>Paid</span><strong>{upcoming ? "₹1,000" : "₹680"}</strong></div></div><div className="booking-actions"><Button variant="secondary" onClick={() => upcoming && go("confirmation")}>{upcoming ? "View Ticket" : "View Details"}</Button>{upcoming && <Button variant="ghost">Cancel Booking</Button>}</div></div>;
}

function Auth({ mode, go }: { mode: "login" | "signup"; go: (screen: Screen) => void }) {
  const signup = mode === "signup";
  return <div className="auth-page"><div className="auth-brand"><Logo onClick={() => go("home")} /></div><div className="auth-layout"><div className="auth-aside"><div className="auth-aside-content"><div className="auth-bus-art"><Icon name="bus" size={56} /></div><div className="auth-quote">Your next journey<br />starts with BusGo.</div><div className="auth-subquote">Easy booking. Safe travel. Happy journeys.</div><div className="auth-points"><span><Icon name="check" size={15} /> 2,000+ trusted bus operators</span><span><Icon name="check" size={15} /> Secure, hassle-free payments</span><span><Icon name="check" size={15} /> 24/7 customer support</span></div></div></div><div className="auth-main"><div className="auth-card"><div className="auth-logo-mobile"><Logo onClick={() => go("home")} /></div><div className="auth-title">{signup ? "Create Your Account" : "Welcome Back"}</div><div className="auth-copy">{signup ? "Sign up to start booking your journeys." : "Log in to manage your trips and bookings."}</div><div className="auth-form">{signup && <Field label="Full Name" value="Arshad Khan" icon="user" />}<Field label="Email Address" value="arshad.khan@email.com" />{signup && <Field label="Mobile Number" value="9876543210" />}<Field label="Password" value="password" type="password" />{signup && <Field label="Confirm Password" value="password" type="password" />}{signup ? <Clickable className="terms-check"><span className="checkbox checked"><Icon name="check" size={12} /></span><span>I agree to the <b>Terms & Conditions</b> and <b>Privacy Policy</b></span></Clickable> : <div className="auth-options"><Clickable className="remember"><span className="checkbox checked"><Icon name="check" size={12} /></span>Remember me</Clickable><span>Forgot Password?</span></div>}<Button full onClick={() => go(signup ? "home" : "home")}>{signup ? "Create Account" : "Login"}</Button>{!signup && <><div className="divider"><span>or</span></div><Button full variant="secondary" icon="google">Continue with Google</Button></>}</div><div className="auth-switch">{signup ? "Already have an account?" : "Don't have an account?"} <Clickable onClick={() => go(signup ? "login" : "signup")}>{signup ? "Login" : "Sign Up"}</Clickable></div></div></div></div></div>;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const go = (next: Screen) => {
    setScreen(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  if (screen === "home") return <Home go={go} />;
  if (screen === "results") return <Results go={go} />;
  if (screen === "seats") return <Seats go={go} />;
  if (screen === "passenger") return <Passenger go={go} />;
  if (screen === "payment") return <Payment go={go} />;
  if (screen === "confirmation") return <Confirmation go={go} />;
  if (screen === "bookings") return <Bookings go={go} />;
  if (screen === "login") return <Auth mode="login" go={go} />;
  return <Auth mode="signup" go={go} />;
}
