import { useState, type ReactNode } from "react";

type Screen =
  | "optionA"
  | "optionB"
  | "review"
  | "home"
  | "listing"
  | "details"
  | "cart"
  | "checkout"
  | "confirmation"
  | "profile"
  | "components";

type IconName =
  | "arrow"
  | "bag"
  | "cart"
  | "check"
  | "chevron"
  | "filter"
  | "heart"
  | "home"
  | "minus"
  | "orders"
  | "plus"
  | "profile"
  | "search"
  | "star"
  | "trash";

const photos = {
  hero:
    "https://images.unsplash.com/photo-1755719401603-159a4eee8c57?auto=format&fit=crop&w=900&q=85",
  headphones:
    "https://images.unsplash.com/photo-1635088760614-5fa0db916be2?auto=format&fit=crop&w=700&q=85",
  watch:
    "https://images.unsplash.com/photo-1649142738067-1c88b4406cc7?auto=format&fit=crop&w=700&q=85",
  tech:
    "https://images.unsplash.com/photo-1721720671231-d3107662343f?auto=format&fit=crop&w=700&q=85",
  essentials:
    "https://images.unsplash.com/photo-1755719401538-79bea384b393?auto=format&fit=crop&w=700&q=85",
};

const products = [
  { name: "Airwave Pro", category: "Audio", price: "$129.00", image: photos.headphones, rating: "4.8" },
  { name: "Orbit Watch", category: "Wearables", price: "$189.00", image: photos.watch, rating: "4.7" },
  { name: "Tech Carry", category: "Accessories", price: "$74.00", image: photos.tech, rating: "4.6" },
  { name: "Daily Kit", category: "Lifestyle", price: "$98.00", image: photos.essentials, rating: "4.9" },
];

const screens: { id: Screen; label: string }[] = [
  { id: "optionA", label: "01 Option A" },
  { id: "optionB", label: "02 Option B" },
  { id: "review", label: "03 Review" },
  { id: "home", label: "04 Home" },
  { id: "listing", label: "05 Products" },
  { id: "details", label: "06 Details" },
  { id: "cart", label: "07 Cart" },
  { id: "checkout", label: "08 Checkout" },
  { id: "confirmation", label: "09 Confirmation" },
  { id: "profile", label: "10 Profile" },
  { id: "components", label: "11 Components" },
];

function Icon({ name, size = 20, filled = false }: { name: IconName; size?: number; filled?: boolean }) {
  const common = {
    fill: filled ? "currentColor" : "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  const paths: Record<IconName, ReactNode> = {
    arrow: <path d="M19 12H5m6-6-6 6 6 6" />,
    bag: <><path d="M6 8h12l-1 12H7L6 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></>,
    cart: <><path d="M3 4h2l2.2 10.5h9.8l2-7H6" /><circle cx="9" cy="19" r="1" /><circle cx="17" cy="19" r="1" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    filter: <><path d="M4 7h16M7 12h10M10 17h4" /><circle cx="8" cy="7" r="1.5" fill="currentColor" stroke="none" /></>,
    heart: <path d="M20.8 4.6a5.4 5.4 0 0 0-7.6 0L12 5.8l-1.2-1.2a5.4 5.4 0 0 0-7.6 7.6L12 21l8.8-8.8a5.4 5.4 0 0 0 0-7.6Z" />,
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
    minus: <path d="M5 12h14" />,
    orders: <><rect x="5" y="3" width="14" height="18" rx="2" /><path d="M9 8h6M9 12h6M9 16h4" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    profile: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    star: <path d="m12 2.5 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5-5.8-3-5.8 3 1.1-6.5-4.7-4.6 6.5-.9L12 2.5Z" />,
    trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14" /><path d="M10 11v6M14 11v6" /></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" {...common}>{paths[name]}</svg>;
}

function Button({
  children,
  onClick,
  variant = "primary",
  className = "",
  disabled = false,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger" | "dark";
  className?: string;
  disabled?: boolean;
}) {
  return <button type="button" disabled={disabled} onClick={onClick} className={`button button-${variant} ${className}`}>{children}</button>;
}

function IconButton({ icon, onClick, label, active = false }: { icon: IconName; onClick?: () => void; label: string; active?: boolean }) {
  return <button type="button" onClick={onClick} className={`icon-button ${active ? "active" : ""}`} aria-label={label}><Icon name={icon} filled={active} /></button>;
}

function PageTitle({ children, overline }: { children: ReactNode; overline?: string }) {
  return <div className="title-wrap">{overline && <div className="overline">{overline}</div>}<div className="page-title">{children}</div></div>;
}

function Header({ title, onBack, action }: { title: string; onBack?: () => void; action?: ReactNode }) {
  return <div className="header">
    <div className="header-side">{onBack && <IconButton icon="arrow" onClick={onBack} label="Go back" />}</div>
    <div className="header-title">{title}</div>
    <div className="header-side end">{action}</div>
  </div>;
}

function StatusBar() {
  return <div className="status-bar"><span>9:41</span><div className="status-icons"><span>●●●</span><span>▰</span></div></div>;
}

function SearchBar({ onClick }: { onClick?: () => void }) {
  return <button type="button" className="search-bar" onClick={onClick}><Icon name="search" size={19} /><span>Search products and brands</span></button>;
}

function BottomNav({ current, go }: { current: Screen; go: (screen: Screen) => void }) {
  const items: { id: Screen; label: string; icon: IconName }[] = [
    { id: "home", label: "Home", icon: "home" },
    { id: "listing", label: "Shop", icon: "bag" },
    { id: "cart", label: "Cart", icon: "cart" },
    { id: "profile", label: "Profile", icon: "profile" },
  ];
  return <div className="bottom-nav">{items.map((item) =>
    <button type="button" className={current === item.id ? "nav-item active" : "nav-item"} onClick={() => go(item.id)} key={item.id}>
      <Icon name={item.icon} filled={current === item.id} /><span>{item.label}</span>
      {item.id === "cart" && <i>1</i>}
    </button>
  )}</div>;
}

function ProductCard({ product, onClick, bold = false }: { product: typeof products[number]; onClick: () => void; bold?: boolean }) {
  return <button type="button" className={`product-card ${bold ? "product-card-bold" : ""}`} onClick={onClick}>
    <div className="product-image-wrap"><img src={product.image} alt={product.name} /><span className="heart-float"><Icon name="heart" size={17} /></span></div>
    <div className="product-copy">
      <div className="product-category">{product.category}</div>
      <div className="product-name">{product.name}</div>
      <div className="product-row"><span className="product-price">{product.price}</span><span className="rating"><Icon name="star" size={13} filled /> {product.rating}</span></div>
    </div>
  </button>;
}

function Device({ children, theme = "a" }: { children: ReactNode; theme?: "a" | "b" }) {
  return <div className={`device theme-${theme}`}><StatusBar />{children}</div>;
}

function MiniHome({ option }: { option: "A" | "B" }) {
  const bold = option === "B";
  return <div className={`mini-home mini-${option.toLowerCase()}`}>
    <div className="mini-head"><span className="mini-logo">S</span><span>ShopEase</span><Icon name="bag" size={13} /></div>
    <div className="mini-search"><Icon name="search" size={11} /><span>Search products</span></div>
    {bold ? <div className="mini-hero"><div><b>Better tech.</b><span>Smarter prices.</span><i>Shop now</i></div><img src={photos.hero} alt="" /></div>
      : <div className="mini-simple"><span>New essentials</span><b>Designed for your everyday.</b><i>Explore collection →</i></div>}
    <div className="mini-label"><b>{bold ? "Trending now" : "Popular products"}</b><span>See all</span></div>
    <div className="mini-grid">{products.slice(0, 2).map((product) => <div className="mini-card" key={product.name}><img src={product.image} alt="" /><b>{product.name}</b><span>{product.price}</span></div>)}</div>
    <div className="mini-nav"><Icon name="home" size={12} filled /><Icon name="bag" size={12} /><Icon name="cart" size={12} /><Icon name="profile" size={12} /></div>
  </div>;
}

function OptionScreen({ option, select, compare }: { option: "A" | "B"; select: () => void; compare: () => void }) {
  const bold = option === "B";
  return <div className={`option-screen option-${option.toLowerCase()}`}>
    <Header title={`Option ${option}`} onBack={compare} action={<span className="step-count">{option === "A" ? "1" : "2"} of 2</span>} />
    <div className="scroll-content option-scroll">
      <div className="option-intro">
        <div className="option-kicker">{bold ? "BOLD MODERN" : "CLEAN MINIMAL"}</div>
        <PageTitle>{bold ? "Designed to engage." : "Clarity in every detail."}</PageTitle>
        <p>{bold ? "High-impact visuals, stronger color and expressive product storytelling." : "Calm, spacious and focused on effortless product discovery."}</p>
      </div>
      <div className="large-preview"><MiniHome option={option} /></div>
      <div className="design-traits">
        {(bold ? ["Vibrant blue surfaces", "Immersive photography", "High-emphasis actions"] : ["Generous white space", "Quiet visual hierarchy", "Utility-first navigation"]).map((trait) =>
          <div key={trait}><span><Icon name="check" size={14} /></span>{trait}</div>
        )}
      </div>
      <Button onClick={select} variant={bold ? "dark" : "primary"}>Select Option {option}</Button>
      <Button onClick={compare} variant="ghost">Back to comparison</Button>
    </div>
  </div>;
}

function ReviewScreen({
  selected,
  approved,
  rating,
  liked,
  feedback,
  submitted,
  setSelected,
  setApproved,
  setRating,
  setLiked,
  setFeedback,
  setSubmitted,
  go,
}: {
  selected: "A" | "B" | null;
  approved: "A" | "B" | "changes" | null;
  rating: number;
  liked: boolean | null;
  feedback: string;
  submitted: boolean;
  setSelected: (value: "A" | "B") => void;
  setApproved: (value: "A" | "B" | "changes") => void;
  setRating: (value: number) => void;
  setLiked: (value: boolean) => void;
  setFeedback: (value: string) => void;
  setSubmitted: (value: boolean) => void;
  go: (screen: Screen) => void;
}) {
  return <div className="review-screen">
    <div className="review-top">
      <div className="brand-lockup"><span>S</span><b>ShopEase</b></div>
      <span className="review-pill">STAKEHOLDER REVIEW</span>
    </div>
    <div className="scroll-content review-content">
      <div className="review-heading">
        <div className="eyebrow">DESIGN DECISION · ROUND 2</div>
        <PageTitle>Stakeholder UI Review</PageTitle>
        <p>Compare both directions and help the team move forward with confidence.</p>
      </div>
      {approved && <div className={`decision-banner ${approved === "changes" ? "changes" : ""}`}><span><Icon name={approved === "changes" ? "filter" : "check"} size={17} /></span><div><b>{approved === "changes" ? "Changes requested" : `Option ${approved} approved`}</b><p>{approved === "changes" ? "Your feedback has been shared with the design team." : "This direction is ready for the next stage."}</p></div></div>}
      <div className="comparison-grid">
        {(["A", "B"] as const).map((option) => <button type="button" className={`comparison-card ${selected === option ? "selected" : ""}`} key={option} onClick={() => setSelected(option)}>
          <div className="preview-wrap"><MiniHome option={option} />{selected === option && <span className="selected-badge"><Icon name="check" size={12} /> Selected</span>}</div>
          <div className="comparison-meta"><div><b>Option {option}</b><span>{option === "A" ? "Clean Minimal" : "Bold Modern"}</span></div><span className="radio"><i /></span></div>
          <span className="view-detail" onClick={(event) => { event.stopPropagation(); go(option === "A" ? "optionA" : "optionB"); }}>View full design <Icon name="chevron" size={14} /></span>
        </button>)}
      </div>
      <div className="feedback-panel">
        <div className="feedback-title">Which design do you prefer?</div>
        <p>Select a direction, then share your feedback below.</p>
        <div className="sentiment-row">
          <div className="sentiment">
            <Button variant={liked === true ? "primary" : "secondary"} onClick={() => setLiked(true)}><span className="thumb">↑</span> Like</Button>
            <Button variant={liked === false ? "danger" : "secondary"} onClick={() => setLiked(false)}><span className="thumb down">↑</span> Dislike</Button>
          </div>
          <div className="stars">{[1, 2, 3, 4, 5].map((value) => <button type="button" aria-label={`${value} star`} onClick={() => setRating(value)} className={value <= rating ? "filled" : ""} key={value}><Icon name="star" size={22} filled={value <= rating} /></button>)}</div>
        </div>
        <label className="field-label" htmlFor="feedback">Feedback</label>
        <textarea id="feedback" value={feedback} onChange={(event) => setFeedback(event.target.value)} placeholder="What works well? What could be improved?" />
        <Button onClick={() => setSubmitted(true)}>
          {submitted ? <><Icon name="check" size={16} /> Feedback Submitted</> : "Submit Feedback"}
        </Button>
        {submitted && <div className="submitted"><Icon name="check" size={15} /> Feedback submitted — thank you.</div>}
      </div>
      <div className="approval-panel">
        <div className="approval-title"><span>Final decision</span><i>Required</i></div>
        <Button variant={approved === "A" ? "primary" : "secondary"} onClick={() => { setSelected("A"); setApproved("A"); }}>Approve Option A</Button>
        <Button variant={approved === "B" ? "dark" : "secondary"} onClick={() => { setSelected("B"); setApproved("B"); }}>Approve Option B</Button>
        <Button variant={approved === "changes" ? "danger" : "ghost"} onClick={() => setApproved("changes")}>Changes Required</Button>
        {(approved === "A" || approved === "B") && <Button onClick={() => go("home")}>Preview approved experience <Icon name="chevron" size={17} /></Button>}
      </div>
    </div>
  </div>;
}

function HomeScreen({ go, bold }: { go: (screen: Screen) => void; bold: boolean }) {
  return <div className="screen-with-nav">
    <div className="scroll-content home-content">
      <div className="home-header"><div><span>Good morning</span><b>Find something you'll love.</b></div><IconButton icon="bag" label="Open cart" onClick={() => go("cart")} /></div>
      <SearchBar onClick={() => go("listing")} />
      <div className="categories">
        {["All", "Audio", "Wearables", "Home"].map((category, index) => <button type="button" className={index === 0 ? "active" : ""} key={category}>{category}</button>)}
      </div>
      <div className={`promo ${bold ? "promo-bold" : ""}`}>
        <div><span>{bold ? "JUST DROPPED" : "NEW COLLECTION"}</span><b>{bold ? "Sound that moves with you." : "Everyday essentials, thoughtfully chosen."}</b><Button variant={bold ? "dark" : "secondary"} onClick={() => go("listing")}>Shop the edit</Button></div>
        <img src={photos.hero} alt="Curated technology accessories" />
      </div>
      <div className="section-heading"><div><span>CURATED FOR YOU</span><b>Popular products</b></div><button type="button" onClick={() => go("listing")}>See all</button></div>
      <div className="product-strip">{products.slice(0, 3).map((product) => <ProductCard key={product.name} product={product} onClick={() => go("details")} bold={bold} />)}</div>
      <div className="benefit-row"><span><Icon name="check" size={15} /> Free shipping</span><span><Icon name="check" size={15} /> 30-day returns</span></div>
    </div>
    <BottomNav current="home" go={go} />
  </div>;
}

function ListingScreen({ go, bold }: { go: (screen: Screen) => void; bold: boolean }) {
  return <div className="screen-with-nav">
    <Header title="All products" onBack={() => go("home")} action={<IconButton icon="cart" label="Open cart" onClick={() => go("cart")} />} />
    <div className="scroll-content listing-content">
      <SearchBar />
      <div className="result-tools"><span><b>48</b> products</span><div><Button variant="secondary"><Icon name="filter" size={16} /> Filter</Button><Button variant="secondary">Popular⌄</Button></div></div>
      <div className="active-filters"><span>In stock <b>×</b></span><span>Under $200 <b>×</b></span></div>
      <div className="product-grid">{products.concat(products.slice(0, 2)).map((product, index) => <ProductCard key={`${product.name}-${index}`} product={product} onClick={() => go("details")} bold={bold} />)}</div>
    </div>
    <BottomNav current="listing" go={go} />
  </div>;
}

function Quantity({ quantity, setQuantity }: { quantity: number; setQuantity: (value: number) => void }) {
  return <div className="quantity"><IconButton icon="minus" label="Decrease quantity" onClick={() => setQuantity(Math.max(1, quantity - 1))} /><b>{quantity}</b><IconButton icon="plus" label="Increase quantity" onClick={() => setQuantity(quantity + 1)} /></div>;
}

function DetailsScreen({ go, quantity, setQuantity, bold }: { go: (screen: Screen) => void; quantity: number; setQuantity: (value: number) => void; bold: boolean }) {
  return <div className="details-screen">
    <div className={`detail-image ${bold ? "bold" : ""}`}><img src={photos.headphones} alt="Airwave Pro wireless headphones" /><div className="floating-header"><IconButton icon="arrow" label="Go back" onClick={() => go("listing")} /><IconButton icon="heart" label="Save product" /></div><div className="image-dots"><i className="active" /><i /><i /></div></div>
    <div className="scroll-content detail-copy">
      <div className="stock-line"><span>BESTSELLER</span><i>In stock</i></div>
      <PageTitle>Airwave Pro</PageTitle>
      <div className="detail-rating"><span><Icon name="star" size={16} filled /> 4.8</span><u>128 reviews</u></div>
      <div className="detail-price">$129.00 <span>$159.00</span></div>
      <p className="description">Immersive sound meets all-day comfort. Premium wireless headphones with adaptive noise cancellation and up to 36 hours of battery life.</p>
      <div className="color-row"><b>Color</b><span>Midnight</span></div>
      <div className="swatches"><i className="black active" /><i className="sand" /><i className="blue" /></div>
      <div className="purchase-row"><Quantity quantity={quantity} setQuantity={setQuantity} /><Button onClick={() => go("cart")}><Icon name="bag" size={19} /> Add to Cart</Button></div>
      <div className="delivery-note"><Icon name="check" size={18} /><div><b>Free delivery by Friday</b><span>Order within 4 hrs 21 min</span></div></div>
    </div>
  </div>;
}

function CartScreen({ go, quantity, setQuantity }: { go: (screen: Screen) => void; quantity: number; setQuantity: (value: number) => void }) {
  const subtotal = quantity * 129;
  return <div className="cart-screen">
    <Header title="Your cart" onBack={() => go("details")} action={<span className="step-count">{quantity} item</span>} />
    <div className="scroll-content cart-content">
      <div className="cart-item"><img src={photos.headphones} alt="Airwave Pro" /><div className="cart-item-copy"><div><span>Audio</span><b>Airwave Pro</b><i>Midnight</i></div><div className="cart-actions"><Quantity quantity={quantity} setQuantity={setQuantity} /><IconButton icon="trash" label="Remove item" /></div></div><strong>$129</strong></div>
      <div className="delivery-card"><span><Icon name="check" size={18} /></span><div><b>You've unlocked free delivery</b><p>Your order will arrive in 2–3 business days.</p></div></div>
      <div className="promo-code"><input aria-label="Promo code" placeholder="Promo code" /><Button variant="secondary">Apply</Button></div>
      <div className="summary"><div><span>Subtotal</span><b>${subtotal.toFixed(2)}</b></div><div><span>Delivery</span><b className="success">Free</b></div><div><span>Tax</span><b>$10.32</b></div><div className="total"><span>Total</span><b>${(subtotal + 10.32).toFixed(2)}</b></div></div>
    </div>
    <div className="sticky-action"><Button onClick={() => go("checkout")}>Checkout · ${(subtotal + 10.32).toFixed(2)} <Icon name="chevron" size={18} /></Button><span>Secure checkout</span></div>
  </div>;
}

function CheckoutScreen({ go, quantity }: { go: (screen: Screen) => void; quantity: number }) {
  return <div className="checkout-screen">
    <Header title="Checkout" onBack={() => go("cart")} action={<span className="secure">Secure</span>} />
    <div className="scroll-content checkout-content">
      <div className="checkout-progress"><span className="done"><Icon name="check" size={12} /></span><i /><span className="active">2</span><i /><span>3</span></div>
      <div className="checkout-section"><div className="checkout-heading"><span>1</span><b>Delivery address</b><button type="button">Edit</button></div><div className="address-card"><b>Alex Morgan</b><span>218 Market Street, Apt 4B</span><span>San Francisco, CA 94105</span><span>+1 (415) 555-0138</span></div></div>
      <div className="checkout-section"><div className="checkout-heading"><span>2</span><b>Payment method</b><button type="button">Change</button></div><div className="payment-card"><span className="visa">VISA</span><div><b>Visa ending in 4242</b><span>Expires 08/28</span></div><i><Icon name="check" size={14} /></i></div></div>
      <div className="checkout-section"><div className="checkout-heading"><span>3</span><b>Order summary</b></div><div className="order-mini"><img src={photos.headphones} alt="" /><div><b>Airwave Pro</b><span>Midnight · Qty {quantity}</span></div><strong>${quantity * 129}.00</strong></div></div>
      <div className="summary compact"><div><span>Subtotal</span><b>${quantity * 129}.00</b></div><div><span>Delivery</span><b className="success">Free</b></div><div><span>Tax</span><b>$10.32</b></div><div className="total"><span>Total</span><b>${(quantity * 129 + 10.32).toFixed(2)}</b></div></div>
    </div>
    <div className="sticky-action"><Button onClick={() => go("confirmation")}><Icon name="check" size={18} /> Place Order</Button><span>By placing your order, you agree to our terms.</span></div>
  </div>;
}

function ConfirmationScreen({ go, quantity }: { go: (screen: Screen) => void; quantity: number }) {
  return <div className="confirmation-screen">
    <div className="confetti one" /><div className="confetti two" /><div className="confetti three" />
    <div className="success-mark"><Icon name="check" size={36} /></div>
    <div className="confirmation-copy"><div className="eyebrow">ORDER CONFIRMED</div><PageTitle>Thank you, Alex!</PageTitle><p>Your order is on its way. We'll send tracking updates to alex.morgan@email.com.</p></div>
    <div className="confirmation-card"><div><span>Order number</span><b>#SE-20481</b></div><div><span>Estimated delivery</span><b>Friday, June 14</b></div><div><span>Total</span><b>${(quantity * 129 + 10.32).toFixed(2)}</b></div></div>
    <div className="confirmation-actions"><Button onClick={() => go("profile")}>View Order</Button><Button variant="ghost" onClick={() => go("home")}>Continue Shopping</Button></div>
  </div>;
}

function ProfileScreen({ go }: { go: (screen: Screen) => void }) {
  const orderRows = [
    { id: "#SE-20481", date: "Jun 11", status: "In transit", image: photos.headphones },
    { id: "#SE-19803", date: "May 24", status: "Delivered", image: photos.watch },
  ];
  return <div className="screen-with-nav">
    <div className="scroll-content profile-content">
      <div className="profile-header"><PageTitle>My account</PageTitle><IconButton icon="filter" label="Settings" /></div>
      <div className="profile-card"><div className="avatar">AM</div><div><b>Alex Morgan</b><span>alex.morgan@email.com</span><i>ShopEase Plus member</i></div><Icon name="chevron" size={19} /></div>
      <div className="profile-stats"><div><b>12</b><span>Orders</span></div><div><b>4</b><span>Saved</span></div><div><b>280</b><span>Points</span></div></div>
      <div className="section-heading"><div><span>ACTIVITY</span><b>Recent orders</b></div><button type="button">View all</button></div>
      <div className="orders-list">{orderRows.map((order) => <button type="button" className="order-row" key={order.id}><img src={order.image} alt="" /><div><b>{order.id}</b><span>{order.date} · 1 item</span><i className={order.status === "Delivered" ? "delivered" : ""}>{order.status}</i></div><Icon name="chevron" size={18} /></button>)}</div>
      <div className="account-links">{["Delivery addresses", "Payment methods", "Help & support"].map((label) => <button type="button" key={label}><span>{label}</span><Icon name="chevron" size={18} /></button>)}</div>
    </div>
    <BottomNav current="profile" go={go} />
  </div>;
}

function ComponentsScreen() {
  return <div>
    <Header title="Component library" />
    <div className="scroll-content components-content">
      <div className="eyebrow">11 COMPONENTS</div><PageTitle>ShopEase UI Kit</PageTitle><p>Reusable foundations supporting both visual directions.</p>
      <div className="component-section"><b>Buttons</b><Button>Primary action</Button><Button variant="secondary">Secondary action</Button><Button variant="dark">Bold action</Button></div>
      <div className="component-section"><b>Form controls</b><SearchBar /><input placeholder="Input field" /><textarea placeholder="Feedback text area" /></div>
      <div className="component-section"><b>Status & rating</b><div className="kit-row"><span className="badge success">Approved</span><span className="badge neutral">In review</span></div><div className="stars static">{[1, 2, 3, 4, 5].map((value) => <span className={value < 5 ? "filled" : ""} key={value}><Icon name="star" size={22} filled={value < 5} /></span>)}</div></div>
      <div className="component-section"><b>Product card</b><div className="single-card"><ProductCard product={products[0]} onClick={() => undefined} /></div></div>
    </div>
  </div>;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("review");
  const [selected, setSelected] = useState<"A" | "B" | null>(null);
  const [approved, setApproved] = useState<"A" | "B" | "changes" | null>(null);
  const [rating, setRating] = useState(0);
  const [liked, setLiked] = useState<boolean | null>(null);
  const [feedback, setFeedback] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const bold = (approved || selected) === "B";
  const go = (next: Screen) => setScreen(next);

  let content: ReactNode;
  if (screen === "optionA") content = <OptionScreen option="A" compare={() => go("review")} select={() => { setSelected("A"); go("review"); }} />;
  else if (screen === "optionB") content = <OptionScreen option="B" compare={() => go("review")} select={() => { setSelected("B"); go("review"); }} />;
  else if (screen === "review") content = <ReviewScreen selected={selected} approved={approved} rating={rating} liked={liked} feedback={feedback} submitted={submitted} setSelected={setSelected} setApproved={setApproved} setRating={setRating} setLiked={setLiked} setFeedback={setFeedback} setSubmitted={setSubmitted} go={go} />;
  else if (screen === "home") content = <HomeScreen go={go} bold={bold} />;
  else if (screen === "listing") content = <ListingScreen go={go} bold={bold} />;
  else if (screen === "details") content = <DetailsScreen go={go} quantity={quantity} setQuantity={setQuantity} bold={bold} />;
  else if (screen === "cart") content = <CartScreen go={go} quantity={quantity} setQuantity={setQuantity} />;
  else if (screen === "checkout") content = <CheckoutScreen go={go} quantity={quantity} />;
  else if (screen === "confirmation") content = <ConfirmationScreen go={go} quantity={quantity} />;
  else if (screen === "profile") content = <ProfileScreen go={go} />;
  else content = <ComponentsScreen />;

  return <div className="app-shell">
    <div className="workspace-header">
      <div className="workspace-brand"><span>S</span><div><b>ShopEase</b><small>Stakeholder prototype · 390 × 844</small></div></div>
      <div className="screen-tabs">{screens.map((item) => <button type="button" key={item.id} className={screen === item.id ? "active" : ""} onClick={() => go(item.id)}>{item.label}</button>)}</div>
    </div>
    <Device theme={bold ? "b" : "a"}>{content}</Device>
    <div className="prototype-note"><span className="live-dot" /> Interactive prototype · Use the index above or tap within the device</div>
  </div>;
}
